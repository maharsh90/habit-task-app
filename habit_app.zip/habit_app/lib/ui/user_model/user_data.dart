import 'dart:convert';

// To parse this JSON data, do
//
//     final userResponse = userResponseFromJson(jsonString);

List<UserResponse> userResponseFromJson(String str) => List<UserResponse>.from(
    json.decode(str).map((x) => UserResponse.fromJson(x)));

String userResponseToJson(List<UserResponse> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class UserResponse {
  int? id;
  String? fullName;
  String? email;
  dynamic emailVerifiedAt;
  int? countryCode;
  int? mobileNumber;
  dynamic username;
  int? isVerified;
  int? isActive;
  String? isDeleted;
  DateTime? createdAt;
  DateTime? updatedAt;

  UserResponse({
    this.id,
    this.fullName,
    this.email,
    this.emailVerifiedAt,
    this.countryCode,
    this.mobileNumber,
    this.username,
    this.isVerified,
    this.isActive,
    this.isDeleted,
    this.createdAt,
    this.updatedAt,
  });

  factory UserResponse.fromJson(Map<String, dynamic> json) => UserResponse(
    id: json["id"],
    fullName: json["full_name"],
    email: json["email"],
    emailVerifiedAt: json["email_verified_at"],
    countryCode: json["country_code"],
    mobileNumber: json["mobile_number"],
    username: json["username"],
    isVerified: json["is_verified"],
    isActive: json["is_active"],
    isDeleted: json["is_deleted"],
    createdAt: json["created_at"] == null
        ? null
        : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null
        ? null
        : DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "full_name": fullName,
    "email": email,
    "email_verified_at": emailVerifiedAt,
    "country_code": countryCode,
    "mobile_number": mobileNumber,
    "username": username,
    "is_verified": isVerified,
    "is_active": isActive,
    "is_deleted": isDeleted,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
  };
}

