import 'package:auto_route/annotations.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:habit_app/router/app_router.dart';
import 'package:provider/provider.dart';

import '../../../generated/l10n.dart';
import '../../../widget/custom_button.dart';
import '../../../widget/custom_textfield.dart';
import '../../provider/multi_theme_provider.dart';

@RoutePage()
class SignupPage extends StatefulWidget {
  const SignupPage({super.key});

  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final GlobalKey<FormState> _formKey=GlobalKey<FormState>();
  late TextEditingController emailController;
  late TextEditingController passwordController;
  late TextEditingController nameController;
  final _auth = FirebaseAuth.instance;
  bool showSpinner = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    emailController=TextEditingController();
    passwordController=TextEditingController();
    nameController=TextEditingController();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    emailController.dispose();
    passwordController.dispose();
    nameController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final multiThemeProvider=Provider.of<MultiThemeProvider>(context,listen: false);
    return Scaffold(
      // backgroundColor: multiThemeProvider.themeColor,
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: Center(
            child: Column(
              spacing: 10.h,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(S.of(context).register,style: TextStyle(fontWeight: FontWeight.bold,fontSize: 18),),
                10.verticalSpace,
                CustomTextFormField(
                  hintColor: multiThemeProvider.themeColor,
                  fillColor: multiThemeProvider.themeColor.withAlpha(20),
                  controller: nameController,
                  hintText: S.of(context).pleaseEnterYourName,
                ),
                CustomTextFormField(
                  hintColor: multiThemeProvider.themeColor,
                  fillColor: multiThemeProvider.themeColor.withAlpha(20),
                  controller: emailController,
                  hintText: S.of(context).pleaseEnterYourEmail,
                ),
                CustomTextFormField(
                  hintColor: multiThemeProvider.themeColor,
                  fillColor: multiThemeProvider.themeColor.withAlpha(20),
                  controller: passwordController,
                  hintText: S.of(context).pleaseEnterYourPassword,
                ),
                showSpinner?Center(child: CircularProgressIndicator(),):CustomButton(
                  color: multiThemeProvider.themeColor,
                  txt: S.of(context).register,
                  voidCallback: () async{
                    if(_formKey.currentState!.validate()){
                      setState(() {
                        showSpinner = true;
                      });
                      try {
                        final newUser = await _auth.createUserWithEmailAndPassword(
                            email: emailController.text,
                            password: passwordController.text);
                        setState(() {
                          showSpinner = false;
                        });
                        nameController.clear();
                        emailController.clear();
                        passwordController.clear();
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(S.of(context).registerSuccessfully)));
                        appRouter.push(LoginRoute());
                      } catch (e) {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
                        print(e);
                      }
                    }
                  },
                ),
                TextButton(onPressed: () {
                  appRouter.replaceAll([LoginRoute()]);
                }, child: Text(S.of(context).alreadyHaveAnAccount),),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
