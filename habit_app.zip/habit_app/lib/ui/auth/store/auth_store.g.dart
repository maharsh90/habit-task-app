// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'auth_store.dart';

// **************************************************************************
// StoreGenerator
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, unnecessary_brace_in_string_interps, unnecessary_lambdas, prefer_expression_function_bodies, lines_longer_than_80_chars, avoid_as, avoid_annotating_with_dynamic, no_leading_underscores_for_local_identifiers

mixin _$AuthStore on _AuthStoreBase, Store {
  late final _$userResponseAtom =
      Atom(name: '_AuthStoreBase.userResponse', context: context);

  @override
  List<UserResponse?>? get userResponse {
    _$userResponseAtom.reportRead();
    return super.userResponse;
  }

  @override
  set userResponse(List<UserResponse?>? value) {
    _$userResponseAtom.reportWrite(value, super.userResponse, () {
      super.userResponse = value;
    });
  }

  late final _$isLoadingAtom =
      Atom(name: '_AuthStoreBase.isLoading', context: context);

  @override
  bool get isLoading {
    _$isLoadingAtom.reportRead();
    return super.isLoading;
  }

  @override
  set isLoading(bool value) {
    _$isLoadingAtom.reportWrite(value, super.isLoading, () {
      super.isLoading = value;
    });
  }

  late final _$getUsersAsyncAction =
      AsyncAction('_AuthStoreBase.getUsers', context: context);

  @override
  Future<void> getUsers() {
    return _$getUsersAsyncAction.run(() => super.getUsers());
  }

  late final _$deleteUserAsyncAction =
      AsyncAction('_AuthStoreBase.deleteUser', context: context);

  @override
  Future<void> deleteUser(int id) {
    return _$deleteUserAsyncAction.run(() => super.deleteUser(id));
  }

  late final _$updateUserAsyncAction =
      AsyncAction('_AuthStoreBase.updateUser', context: context);

  @override
  Future<void> updateUser(int id, Map<String, dynamic> user) {
    return _$updateUserAsyncAction.run(() => super.updateUser(id, user));
  }

  @override
  String toString() {
    return '''
userResponse: ${userResponse},
isLoading: ${isLoading}
    ''';
  }
}
