import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:habit_app/ui/user_model/user_data.dart';
import 'package:mobx/mobx.dart';

import '../../../core/exceptions/app_exceptions.dart';
import '../../../core/exceptions/dio_exceptio_util.dart';
import '../../../core/locator/locator.dart';
import '../../../data/repository_impl/auth_repo_impl.dart';

part 'auth_store.g.dart';

class AuthStore = _AuthStoreBase with _$AuthStore;

abstract class _AuthStoreBase with Store {

  @observable
  List<UserResponse?>? userResponse;

  @observable
  bool isLoading = false;

  @observable
  String? errorMessage;

  @action
  Future<void> getUsers() async {
    try {
      errorMessage = null;
      isLoading = true;
      final data = await authRepo.getUser();
      print("data is ${data}");
      userResponse = data;
      isLoading = false;
    } on DioException catch (dioError) {
      errorMessage = DioExceptionUtil.handleError(dioError);
    } on AppException catch (e) {
      errorMessage = e.toString();
    } catch (e, st) {
      debugPrintStack(stackTrace: st);
      errorMessage = e.toString();
    }
  }

  @action
  Future<void> deleteUser(int id) async {
    try{
      errorMessage = null;
      await authRepo.deleteUser(id);
    }on DioException catch (dioError) {
      errorMessage = DioExceptionUtil.handleError(dioError);
    } on AppException catch (e) {
      errorMessage = e.toString();
    } catch (e, st) {
      debugPrintStack(stackTrace: st);
      errorMessage = e.toString();
    }
  }

  @action
  Future<void> updateUser(int id, Map<String, dynamic> user) async {
    try{
      errorMessage = null;
      await authRepo.updateUser(id, user);
    }on DioException catch (dioError) {
      errorMessage = DioExceptionUtil.handleError(dioError);
    } on AppException catch (e) {
      errorMessage = e.toString();
    } catch (e, st) {
      debugPrintStack(stackTrace: st);
      errorMessage = e.toString();
    }
  }
}

final authStore = getIt<AuthStore>();
