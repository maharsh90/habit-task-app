import 'package:auto_route/annotations.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:habit_app/core/db/app_db.dart';
import 'package:habit_app/router/app_router.dart';
import 'package:provider/provider.dart';

import '../../../generated/l10n.dart';
import '../../../widget/custom_button.dart';
import '../../../widget/custom_textfield.dart';
import '../../provider/multi_theme_provider.dart';

@RoutePage()
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  List<Color> multiThemeColors=[Colors.orange.shade300,Colors.red.shade300,Colors.green.shade300,Colors.blue.shade300,Colors.purple.shade300];
  final GlobalKey<FormState> _formKey=GlobalKey<FormState>();
  late TextEditingController emailController;
  late TextEditingController passwordController;
  bool showSpinner = false;
  final _auth = FirebaseAuth.instance;
  final snackBar = SnackBar(content: Text(S.current.yayASnackbar));

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    emailController=TextEditingController();
    passwordController=TextEditingController();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    emailController.dispose();
    passwordController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final multiThemeProvider=Provider.of<MultiThemeProvider>(context,listen: false);
    return Scaffold(
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: Center(
            child: Column(
              spacing: 10.h,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(S.of(context).login,style: TextStyle(fontWeight: FontWeight.bold,fontSize: 18),),
                10.verticalSpace,
                CustomTextFormField(
                  fillColor: multiThemeProvider.themeColor.withAlpha(20),
                  hintColor: multiThemeProvider.themeColor,
                  controller: emailController,
                  hintText: S.of(context).pleaseEnterYourEmail,
                ),
                CustomTextFormField(
                  hintColor: multiThemeProvider.themeColor,
                  fillColor: multiThemeProvider.themeColor.withAlpha(20),
                  controller: passwordController,
                  hintText: S.of(context).pleaseEnterYourPassword,
                ),
                showSpinner?Center(child: CircularProgressIndicator(),):CustomButton(
                  color: multiThemeProvider.themeColor,
                  txt: S.of(context).login,
                  voidCallback: () async{
                    if(_formKey.currentState!.validate()){
                      setState(() {
                        showSpinner=true;
                      });
                      try {
                        final user = await _auth.signInWithEmailAndPassword(
                            email: emailController.text,
                            password: passwordController.text);
                        if (user != null) {
                          emailController.clear();
                          passwordController.clear();
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(S.of(context).loginSuccessfully)));
                          appRouter.replaceAll([UsersListRoute()]);
                          print("login success");

                        }
                        setState(() {
                          showSpinner = false;
                        });
                        appDB.isLogin=true;
                      } catch (e) {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
                        print(e);
                      }
                      print("form submitted successfully");
                    }
                  },
                ),
                10.verticalSpace,
                TextButton(onPressed: () {
                  appRouter.replaceAll([SignupRoute()]);
                }, child: Text(S.of(context).createAnAccount),),
                SizedBox(width: 300.w,child: Text(textAlign: TextAlign.center,maxLines: 2,overflow: TextOverflow.ellipsis,S.of(context).clickThisBelowMulticolorPaletteToChangeTheEntireApp)),
                5.verticalSpace,
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(multiThemeColors.length, (index) {
                    int selectedIndex=multiThemeProvider.selectedIndex;
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          multiThemeProvider.setSelectedIndex(index);
                          multiThemeProvider.setThemeColor(multiThemeColors[index]);
                        });
                      },
                      child: Consumer(
                        builder: (context, value, child) {
                          return  Container(
                            margin: EdgeInsets.only(right: 10),
                            height: selectedIndex==index?35.h:30.h,
                            width: selectedIndex==index?35.w:30.w,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: selectedIndex==index?Border.all(color: Colors.black,width: 3):null,
                              color: multiThemeColors[index],
                            ),
                          );
                        },
                      ),
                    );
                  },)
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
