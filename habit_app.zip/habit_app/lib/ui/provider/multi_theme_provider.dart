import 'package:flutter/material.dart';

class MultiThemeProvider extends ChangeNotifier {
  Color _themeColor = Colors.orange.shade300;

  int _selectedIndex=0;

  Color get themeColor=>_themeColor;

  int get selectedIndex=>_selectedIndex;

  void setThemeColor(Color color){
    _themeColor=color;
    notifyListeners();
  }

  void setSelectedIndex(int index){
    _selectedIndex=index;
    notifyListeners();
  }
}
