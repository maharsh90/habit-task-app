import 'package:auto_route/annotations.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:habit_app/router/app_router.dart';
import 'package:habit_app/ui/user_model/user_data.dart';
import 'package:provider/provider.dart';

import '../../generated/l10n.dart';
import '../../widget/custom_button.dart';
import '../../widget/custom_textfield.dart';
import '../auth/store/auth_store.dart';
import '../provider/multi_theme_provider.dart';

@RoutePage()
class UsersListPage extends StatefulWidget {
  const UsersListPage({super.key});

  @override
  State<UsersListPage> createState() => _UsersListPageState();
}

class _UsersListPageState extends State<UsersListPage> {
  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  ValueNotifier<bool> isLoading=ValueNotifier<bool>(true);
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    authStore.getUsers();
    nameController = TextEditingController();
    emailController = TextEditingController();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    nameController.dispose();
    emailController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final multiThemeProvider=Provider.of<MultiThemeProvider>(context,listen: false);
    return Scaffold(
      appBar: AppBar(
        title: Text(S.of(context).usersListPage),
        actions: [
          IconButton(onPressed: () {
            appRouter.replaceAll([LoginRoute()]);
          }, icon: Icon(Icons.logout))
        ],
      ),
      body: Observer(
        builder: (_) {
          if (authStore.isLoading) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          } else if (authStore.userResponse == null ||
              authStore.userResponse!.isEmpty) {
            return Center(
              child: Text(S.of(context).noUsersAvailable),
            );
          } else {
            return ListView.builder(
              itemCount: authStore.userResponse!.length,
              itemBuilder: (context, index) {
                final user = authStore.userResponse![index];
                return Container(
                  margin: EdgeInsets.all(10.h),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10.r),
                    color: multiThemeProvider.themeColor.withAlpha(30),
                  ),
                  child: ListTile(
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          onPressed: () {
                            if(user!=null){
                              nameController.text = user.username ?? '';
                              emailController.text = user.email ?? '';
                              showModalBottomSheet(
                                isDismissible: true,
                                showDragHandle: false,
                                context: context,
                                builder: (context) => editUser(user,multiThemeProvider),
                              );
                            }
                          },
                          icon: const Icon(Icons.edit),
                        ),
                        IconButton(
                          onPressed: () {
                            deleteDialog(context, user!.id!);
                          },
                          icon: const Icon(Icons.delete, color: Colors.red),
                        ),
                      ],
                    ),
                    title: Text('${user!.username}'),
                    subtitle: Text(user.email!),
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }

  Future<dynamic> deleteDialog(BuildContext context, int index) {
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        content: Text(
          S.of(context).doYouWantToDelete,
          style: TextStyle(fontSize: 18, color: Colors.red),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text(S.of(context).no),
          ),
          TextButton(
            onPressed: () {
              authStore.deleteUser(index);
              authStore.getUsers();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(S.of(context).deleteSuccessfully),
                ),
              );
              Navigator.pop(context);
              setState(() {});
            },
            child: Text(S.of(context).yes),
          ),
        ],
      ),
    );
  }

  Padding editUser(UserResponse user,MultiThemeProvider multiThemeProvider) {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        children: [
          Text(
            S.of(context).edit,
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(
            height: 30,
          ),
          CustomTextFormField(
            fillColor: multiThemeProvider.themeColor.withAlpha(20),
            hintColor: multiThemeProvider.themeColor,
            controller: nameController,
            hintText: S.of(context).enterName,
          ),
          const SizedBox(
            height: 10,
          ),
          CustomTextFormField(
            fillColor: multiThemeProvider.themeColor.withAlpha(20),
            hintColor: multiThemeProvider.themeColor,
            controller: emailController,
            hintText: S.of(context).enterJob,
          ),
          const SizedBox(
            height: 10,
          ),
          CustomButton(
            color: multiThemeProvider.themeColor,
            txt: S.of(context).save,
            voidCallback: () {
              var userData = UserResponse(
                fullName: nameController.text,
                email: emailController.text,
              ).toJson();
              authStore.updateUser(user.id!, userData);
              authStore.getUsers();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(S.of(context).updateSuccessfully),
                ),
              );
              setState(() {});
              print(user);
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }
}



