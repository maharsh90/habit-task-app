import 'package:habit_app/ui/user_model/user_data.dart';

import '../../core/locator/locator.dart';
import '../remote/auth_api.dart';
import '../repository/auth_repo.dart';

class AuthRepoImpl extends AuthRepository {
  AuthApi authApi;

  AuthRepoImpl({required this.authApi});

  @override
  Future<List<UserResponse?>> getUser() async {
    final res = await authApi.getUser();
    return res;
  }

  @override
  Future<UserResponse?> deleteUser(int id) async {
    try {
      final res = await authApi.deleteUser(id);
        await getUser();
        return res;
    } catch (e) {
      throw Exception(e);
    }
  }

  @override
  Future<UserResponse?> updateUser(
      int id, Map<String, dynamic> user) async {
    try {
      final res = await authApi.updateUser(id, user);
      print(user);
      return res;
    } catch (e) {
      print('Error Updating users: $e');
      throw e.toString();
    }
  }
}

final authRepo = getIt<AuthRepoImpl>();
