
import 'package:habit_app/ui/user_model/user_data.dart';

abstract class AuthRepository {

  Future<List<UserResponse?>> getUser();

  Future<UserResponse?> updateUser(
      int id, Map<String, dynamic> user);

  Future<UserResponse?> deleteUser(int id);
}
