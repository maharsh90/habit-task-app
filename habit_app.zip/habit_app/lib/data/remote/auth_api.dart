import 'package:dio/dio.dart';
import 'package:habit_app/ui/user_model/user_data.dart';
import 'package:retrofit/error_logger.dart';
import 'package:retrofit/http.dart';

import '../../core/api/api_end_points.dart';

part 'auth_api.g.dart';

@RestApi()
abstract class AuthApi {
  factory AuthApi(Dio dio) = _AuthApi;

  @GET(APIEndPoints.user)
  Future<List<UserResponse?>> getUser();

  @DELETE("${APIEndPoints.user}/{id}")
  Future<UserResponse?> deleteUser(@Path("id") int id);

  @PUT("${APIEndPoints.user}/{id}")
  Future<UserResponse?> updateUser(
      @Path("id") int id, @Body() Map<String, dynamic> user);
}
