import 'package:json_annotation/json_annotation.dart';

part 'login_request_model.g.dart';

@JsonSerializable(
  ignoreUnannotated: false,
  includeIfNull: false,
)
class LoginRequestModel {
  @JsonKey(name: 'email')
  String? email;
  @JsonKey(name: 'country_code')
  String? countryCode;
  @JsonKey(name: 'phone')
  String? phone;
  @JsonKey(name: 'password')
  String? password;
  @JsonKey(name: 'address')
  String? address;

  LoginRequestModel(
      {this.email,
        this.countryCode,
        this.phone,
        this.password,
        this.address,});

  factory LoginRequestModel.fromJson(Map<String, dynamic> json) =>
      _$LoginRequestModelFromJson(json);

  Map<String, dynamic> toJson() => _$LoginRequestModelToJson(this);
}
