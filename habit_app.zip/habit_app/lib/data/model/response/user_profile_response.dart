import 'package:hive/hive.dart';
import 'package:json_annotation/json_annotation.dart';

part 'user_profile_response.g.dart';

@JsonSerializable(explicitToJson: true)
@HiveType(typeId: 0)
class UserData {
  @HiveField(0)
  @JsonKey(name: "id")
  int? id;
  @HiveField(1)
  @JsonKey(name: "mobile_number")
  String? mobileNumber;
  @HiveField(2)
  @JsonKey(name: "name")
  String? name;
  @HiveField(3)
  @JsonKey(name: "email")
  String? email;
  @HiveField(4)
  @JsonKey(name: "country_code")
  String? countryCode;
  @HiveField(5)
  @JsonKey(name: "profile_image")
  String? profileImage;
  @HiveField(6)
  @JsonKey(name: "date_of_birth")
  String? dob;

  UserData({
    this.id,
    this.mobileNumber,
    this.name,
    this.email,
    this.profileImage,
    this.countryCode,
    this.dob,
  });

  static UserData fromJson(Map<String, dynamic> json) =>
      _$UserDataFromJson(json);

  Map<String, dynamic> toJson() => _$UserDataToJson(this);
}
