import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class CustomButton extends StatefulWidget {
  CustomButton({super.key, required this.txt, this.voidCallback,this.color});
  String txt;
  VoidCallback? voidCallback;
  Color? color;

  @override
  State<CustomButton> createState() => _CustomButtonState();
}

class _CustomButtonState extends State<CustomButton> {
  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: widget.color,
        minimumSize: Size(200.w, 35.h),
        foregroundColor: Colors.white,
      ),
      onPressed: widget.voidCallback,
      child: Text(widget.txt.toString()),
    );
  }
}