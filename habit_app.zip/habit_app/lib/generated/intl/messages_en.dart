// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a en locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'en';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "alreadyHaveAnAccount":
            MessageLookupByLibrary.simpleMessage("Already Have an Account"),
        "clickThisBelowMulticolorPaletteToChangeTheEntireApp":
            MessageLookupByLibrary.simpleMessage(
                "Click this below multiColor palette to change the entire app theme"),
        "connectionTimeoutWithServer": MessageLookupByLibrary.simpleMessage(
            "connection Timeout With Server"),
        "connectionToServerFailedDueToInternetConnection":
            MessageLookupByLibrary.simpleMessage(
                "connection To Server Failed Due To Internet Connection"),
        "connectionToServerFailedDueToInternetconnection":
            MessageLookupByLibrary.simpleMessage(
                "connection To Server Failed Due To InternetConnection"),
        "createAnAccount":
            MessageLookupByLibrary.simpleMessage("Create an account"),
        "deleteSuccessfully":
            MessageLookupByLibrary.simpleMessage("delete successfully"),
        "doYouWantToDelete":
            MessageLookupByLibrary.simpleMessage("Do you want to Delete ?"),
        "edit": MessageLookupByLibrary.simpleMessage("Edit"),
        "enterJob": MessageLookupByLibrary.simpleMessage("Enter job"),
        "enterName": MessageLookupByLibrary.simpleMessage("Enter Name"),
        "errorDuringCommunication":
            MessageLookupByLibrary.simpleMessage("error During Communication"),
        "invalidRequest":
            MessageLookupByLibrary.simpleMessage("invalid Request"),
        "invalidinput": MessageLookupByLibrary.simpleMessage("invalidInput"),
        "login": MessageLookupByLibrary.simpleMessage("Login"),
        "loginSuccessfully":
            MessageLookupByLibrary.simpleMessage("login successfully"),
        "no": MessageLookupByLibrary.simpleMessage("No"),
        "noActiveInternetConnection": MessageLookupByLibrary.simpleMessage(
            "no Active Internet Connection"),
        "noUsersAvailable":
            MessageLookupByLibrary.simpleMessage("No users available"),
        "pleaseEnterYourEmail":
            MessageLookupByLibrary.simpleMessage("Please Enter your email"),
        "pleaseEnterYourName":
            MessageLookupByLibrary.simpleMessage("Please Enter your name"),
        "pleaseEnterYourPassword":
            MessageLookupByLibrary.simpleMessage("Please Enter your password"),
        "pleaseLoginAgain":
            MessageLookupByLibrary.simpleMessage("please Login Again"),
        "register": MessageLookupByLibrary.simpleMessage("Register"),
        "registerPage": MessageLookupByLibrary.simpleMessage("Register Page"),
        "registerSuccessfully":
            MessageLookupByLibrary.simpleMessage("Register successfully"),
        "requestCantBeHandledForNowPleaseTryAfterSometime":
            MessageLookupByLibrary.simpleMessage(
                "request Cant Be Handled For Now Please Try After Sometime"),
        "requestToServerWasCancelled": MessageLookupByLibrary.simpleMessage(
            "request To Server Was Cancelled"),
        "save": MessageLookupByLibrary.simpleMessage("Save"),
        "somethingWentWrongPleaseTryAfterSometime":
            MessageLookupByLibrary.simpleMessage(
                "something Went Wrong Please Try After Sometime"),
        "somethingWentWrongPleaseTryagain":
            MessageLookupByLibrary.simpleMessage(
                "something Went Wrong Please TryAgain"),
        "unauthorised": MessageLookupByLibrary.simpleMessage("unauthorised"),
        "updateSuccessfully":
            MessageLookupByLibrary.simpleMessage("update successfully"),
        "usersListPage":
            MessageLookupByLibrary.simpleMessage("Users List Page"),
        "yayASnackbar":
            MessageLookupByLibrary.simpleMessage("Yay! A SnackBar!"),
        "yes": MessageLookupByLibrary.simpleMessage("Yes")
      };
}
