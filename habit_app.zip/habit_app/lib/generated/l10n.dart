// GENERATED CODE - DO NOT MODIFY BY HAND
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'intl/messages_all.dart';

// **************************************************************************
// Generator: Flutter Intl IDE plugin
// Made by Localizely
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, lines_longer_than_80_chars
// ignore_for_file: join_return_with_assignment, prefer_final_in_for_each
// ignore_for_file: avoid_redundant_argument_values, avoid_escaping_inner_quotes

class S {
  S();

  static S? _current;

  static S get current {
    assert(_current != null,
        'No instance of S was loaded. Try to initialize the S delegate before accessing S.current.');
    return _current!;
  }

  static const AppLocalizationDelegate delegate = AppLocalizationDelegate();

  static Future<S> load(Locale locale) {
    final name = (locale.countryCode?.isEmpty ?? false)
        ? locale.languageCode
        : locale.toString();
    final localeName = Intl.canonicalizedLocale(name);
    return initializeMessages(localeName).then((_) {
      Intl.defaultLocale = localeName;
      final instance = S();
      S._current = instance;

      return instance;
    });
  }

  static S of(BuildContext context) {
    final instance = S.maybeOf(context);
    assert(instance != null,
        'No instance of S present in the widget tree. Did you add S.delegate in localizationsDelegates?');
    return instance!;
  }

  static S? maybeOf(BuildContext context) {
    return Localizations.of<S>(context, S);
  }

  /// `Please Enter your email`
  String get pleaseEnterYourEmail {
    return Intl.message(
      'Please Enter your email',
      name: 'pleaseEnterYourEmail',
      desc: '',
      args: [],
    );
  }

  /// `Please Enter your password`
  String get pleaseEnterYourPassword {
    return Intl.message(
      'Please Enter your password',
      name: 'pleaseEnterYourPassword',
      desc: '',
      args: [],
    );
  }

  /// `error During Communication`
  String get errorDuringCommunication {
    return Intl.message(
      'error During Communication',
      name: 'errorDuringCommunication',
      desc: '',
      args: [],
    );
  }

  /// `invalid Request`
  String get invalidRequest {
    return Intl.message(
      'invalid Request',
      name: 'invalidRequest',
      desc: '',
      args: [],
    );
  }

  /// `unauthorised`
  String get unauthorised {
    return Intl.message(
      'unauthorised',
      name: 'unauthorised',
      desc: '',
      args: [],
    );
  }

  /// `invalidInput`
  String get invalidinput {
    return Intl.message(
      'invalidInput',
      name: 'invalidinput',
      desc: '',
      args: [],
    );
  }

  /// `no Active Internet Connection`
  String get noActiveInternetConnection {
    return Intl.message(
      'no Active Internet Connection',
      name: 'noActiveInternetConnection',
      desc: '',
      args: [],
    );
  }

  /// `connection To Server Failed Due To Internet Connection`
  String get connectionToServerFailedDueToInternetConnection {
    return Intl.message(
      'connection To Server Failed Due To Internet Connection',
      name: 'connectionToServerFailedDueToInternetConnection',
      desc: '',
      args: [],
    );
  }

  /// `something Went Wrong Please Try After Sometime`
  String get somethingWentWrongPleaseTryAfterSometime {
    return Intl.message(
      'something Went Wrong Please Try After Sometime',
      name: 'somethingWentWrongPleaseTryAfterSometime',
      desc: '',
      args: [],
    );
  }

  /// `request To Server Was Cancelled`
  String get requestToServerWasCancelled {
    return Intl.message(
      'request To Server Was Cancelled',
      name: 'requestToServerWasCancelled',
      desc: '',
      args: [],
    );
  }

  /// `connection Timeout With Server`
  String get connectionTimeoutWithServer {
    return Intl.message(
      'connection Timeout With Server',
      name: 'connectionTimeoutWithServer',
      desc: '',
      args: [],
    );
  }

  /// `request Cant Be Handled For Now Please Try After Sometime`
  String get requestCantBeHandledForNowPleaseTryAfterSometime {
    return Intl.message(
      'request Cant Be Handled For Now Please Try After Sometime',
      name: 'requestCantBeHandledForNowPleaseTryAfterSometime',
      desc: '',
      args: [],
    );
  }

  /// `connection To Server Failed Due To InternetConnection`
  String get connectionToServerFailedDueToInternetconnection {
    return Intl.message(
      'connection To Server Failed Due To InternetConnection',
      name: 'connectionToServerFailedDueToInternetconnection',
      desc: '',
      args: [],
    );
  }

  /// `please Login Again`
  String get pleaseLoginAgain {
    return Intl.message(
      'please Login Again',
      name: 'pleaseLoginAgain',
      desc: '',
      args: [],
    );
  }

  /// `something Went Wrong Please TryAgain`
  String get somethingWentWrongPleaseTryagain {
    return Intl.message(
      'something Went Wrong Please TryAgain',
      name: 'somethingWentWrongPleaseTryagain',
      desc: '',
      args: [],
    );
  }

  /// `Login`
  String get login {
    return Intl.message(
      'Login',
      name: 'login',
      desc: '',
      args: [],
    );
  }

  /// `Create an account`
  String get createAnAccount {
    return Intl.message(
      'Create an account',
      name: 'createAnAccount',
      desc: '',
      args: [],
    );
  }

  /// `Please Enter your name`
  String get pleaseEnterYourName {
    return Intl.message(
      'Please Enter your name',
      name: 'pleaseEnterYourName',
      desc: '',
      args: [],
    );
  }

  /// `Register`
  String get register {
    return Intl.message(
      'Register',
      name: 'register',
      desc: '',
      args: [],
    );
  }

  /// `Register Page`
  String get registerPage {
    return Intl.message(
      'Register Page',
      name: 'registerPage',
      desc: '',
      args: [],
    );
  }

  /// `Already Have an Account`
  String get alreadyHaveAnAccount {
    return Intl.message(
      'Already Have an Account',
      name: 'alreadyHaveAnAccount',
      desc: '',
      args: [],
    );
  }

  /// `Yay! A SnackBar!`
  String get yayASnackbar {
    return Intl.message(
      'Yay! A SnackBar!',
      name: 'yayASnackbar',
      desc: '',
      args: [],
    );
  }

  /// `login successfully`
  String get loginSuccessfully {
    return Intl.message(
      'login successfully',
      name: 'loginSuccessfully',
      desc: '',
      args: [],
    );
  }

  /// `Click this below multiColor palette to change the entire app theme`
  String get clickThisBelowMulticolorPaletteToChangeTheEntireApp {
    return Intl.message(
      'Click this below multiColor palette to change the entire app theme',
      name: 'clickThisBelowMulticolorPaletteToChangeTheEntireApp',
      desc: '',
      args: [],
    );
  }

  /// `Register successfully`
  String get registerSuccessfully {
    return Intl.message(
      'Register successfully',
      name: 'registerSuccessfully',
      desc: '',
      args: [],
    );
  }

  /// `Users List Page`
  String get usersListPage {
    return Intl.message(
      'Users List Page',
      name: 'usersListPage',
      desc: '',
      args: [],
    );
  }

  /// `No users available`
  String get noUsersAvailable {
    return Intl.message(
      'No users available',
      name: 'noUsersAvailable',
      desc: '',
      args: [],
    );
  }

  /// `Do you want to Delete ?`
  String get doYouWantToDelete {
    return Intl.message(
      'Do you want to Delete ?',
      name: 'doYouWantToDelete',
      desc: '',
      args: [],
    );
  }

  /// `No`
  String get no {
    return Intl.message(
      'No',
      name: 'no',
      desc: '',
      args: [],
    );
  }

  /// `Yes`
  String get yes {
    return Intl.message(
      'Yes',
      name: 'yes',
      desc: '',
      args: [],
    );
  }

  /// `Enter Name`
  String get enterName {
    return Intl.message(
      'Enter Name',
      name: 'enterName',
      desc: '',
      args: [],
    );
  }

  /// `Enter job`
  String get enterJob {
    return Intl.message(
      'Enter job',
      name: 'enterJob',
      desc: '',
      args: [],
    );
  }

  /// `Save`
  String get save {
    return Intl.message(
      'Save',
      name: 'save',
      desc: '',
      args: [],
    );
  }

  /// `Edit`
  String get edit {
    return Intl.message(
      'Edit',
      name: 'edit',
      desc: '',
      args: [],
    );
  }

  /// `delete successfully`
  String get deleteSuccessfully {
    return Intl.message(
      'delete successfully',
      name: 'deleteSuccessfully',
      desc: '',
      args: [],
    );
  }

  /// `update successfully`
  String get updateSuccessfully {
    return Intl.message(
      'update successfully',
      name: 'updateSuccessfully',
      desc: '',
      args: [],
    );
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<S> {
  const AppLocalizationDelegate();

  List<Locale> get supportedLocales {
    return const <Locale>[
      Locale.fromSubtags(languageCode: 'en'),
    ];
  }

  @override
  bool isSupported(Locale locale) => _isSupported(locale);
  @override
  Future<S> load(Locale locale) => S.load(locale);
  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  bool _isSupported(Locale locale) {
    for (var supportedLocale in supportedLocales) {
      if (supportedLocale.languageCode == locale.languageCode) {
        return true;
      }
    }
    return false;
  }
}
