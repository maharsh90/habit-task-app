import 'dart:async';
import 'package:dio/dio.dart';

import '../../data/remote/auth_api.dart';
import '../locator/locator.dart';
import 'api_end_points.dart';

class ApiModule {
  Future<void> provides() async {
    final dio = await setup();

    /// register [Dio] to [GetIt]
    getIt.registerSingleton(dio);

    /// register APIs implementations
    getIt.registerSingleton(AuthApi(dio));
  }

  static FutureOr<Dio> setup() async {
    final Dio dio = Dio()
      ..options = BaseOptions(
        baseUrl: APIEndPoints.baseUrl,
        validateStatus: (status) {
          if (status == null) return true;
          if (status == 401 || status >= 500) return false;
          return true;
        },
        responseType: ResponseType.plain,
        headers: {
          'content-type': 'text/plain',
          'contentType': 'text/plain',
          'responseType': 'text/plain',
        },
      );
    return dio;
  }
}
