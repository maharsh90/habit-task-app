abstract class APIEndPoints {
  APIEndPoints._();

  static const String baseUrl = 'https://jsonplaceholder.typicode.com';
  static const String user = '/users';

}