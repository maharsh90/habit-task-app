import 'dart:io';

import 'package:get_it/get_it.dart';
import 'package:habit_app/router/app_router.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';

import '../../data/model/response/user_profile_response.dart';
import '../../data/repository_impl/auth_repo_impl.dart';
import '../../ui/auth/store/auth_store.dart';
import '../api/api_module.dart';
import '../db/app_db.dart';

final getIt = GetIt.instance;

Future<void> setupLocator() async {
  /// setup navigator instance
  getIt.registerSingleton(AppRouter());

  /// setup hive
  final appDocumentDir = Platform.isAndroid
      ? await getApplicationDocumentsDirectory()
      : await getLibraryDirectory();

  Hive
    ..init(appDocumentDir.path)
    ..registerAdapter(UserDataAdapter());

  /// setup API modules with repos which requires [Dio] instance
  await ApiModule().provides();

  getIt.registerSingletonAsync<AppDB>(() => AppDB.getInstance());

  /// register repositories implementation
  getIt.registerFactory<AuthRepoImpl>(
        () => AuthRepoImpl(authApi: getIt()),
  );

  /// register stores if only you requires singleton
  getIt.registerLazySingleton<AuthStore>(() => AuthStore());
}