import 'package:auto_route/annotations.dart';
import 'package:auto_route/auto_route.dart';
import 'package:habit_app/core/locator/locator.dart';

import '../ui/auth/login/login_page.dart';
import '../ui/auth/sign_up/sign_up_page.dart';
import '../ui/user_list/user_list_page.dart';

part 'app_router.gr.dart';

@AutoRouterConfig(
  replaceInRouteName: 'Page,Route',
)
// extend the generated private router
class AppRouter extends _$AppRouter {
  @override
  RouteType get defaultRouteType => const RouteType.material();

  @override
  final List<AutoRoute> routes = [
    AutoRoute(page: LoginRoute.page,initial: true),
    AutoRoute(page: SignupRoute.page),
    AutoRoute(page: UsersListRoute.page),
  ];
}

final appRouter = getIt<AppRouter>();

